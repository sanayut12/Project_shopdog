﻿namespace ShopdogV1
{
    partial class Main_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel_main = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.user_name_label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.butt_notnever_bub = new System.Windows.Forms.Button();
            this.butt_histrory = new System.Windows.Forms.Button();
            this.butt_selling = new System.Windows.Forms.Button();
            this.butt_push = new System.Windows.Forms.Button();
            this.butt_pro = new System.Windows.Forms.Button();
            this.butt_home = new System.Windows.Forms.Button();
            this.imageUser_pic = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageUser_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1500, 40);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.panel3.Controls.Add(this.panel_main);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Location = new System.Drawing.Point(0, 40);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1500, 960);
            this.panel3.TabIndex = 1;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel_main
            // 
            this.panel_main.BackColor = System.Drawing.Color.Transparent;
            this.panel_main.Location = new System.Drawing.Point(0, 0);
            this.panel_main.Name = "panel_main";
            this.panel_main.Size = new System.Drawing.Size(1300, 960);
            this.panel_main.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Yellow;
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(1300, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 960);
            this.panel2.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.panel7.Controls.Add(this.user_name_label);
            this.panel7.Controls.Add(this.label1);
            this.panel7.Location = new System.Drawing.Point(10, 200);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(180, 25);
            this.panel7.TabIndex = 3;
            // 
            // user_name_label
            // 
            this.user_name_label.AutoSize = true;
            this.user_name_label.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.user_name_label.Location = new System.Drawing.Point(90, 4);
            this.user_name_label.Name = "user_name_label";
            this.user_name_label.Size = new System.Drawing.Size(42, 17);
            this.user_name_label.TabIndex = 3;
            this.user_name_label.Text = "None";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(0, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "User name : ";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.butt_notnever_bub);
            this.panel6.Controls.Add(this.butt_histrory);
            this.panel6.Controls.Add(this.butt_selling);
            this.panel6.Controls.Add(this.butt_push);
            this.panel6.Controls.Add(this.butt_pro);
            this.panel6.Controls.Add(this.butt_home);
            this.panel6.Location = new System.Drawing.Point(10, 250);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(180, 364);
            this.panel6.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.panel5.Controls.Add(this.imageUser_pic);
            this.panel5.Location = new System.Drawing.Point(10, 10);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(180, 180);
            this.panel5.TabIndex = 0;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Image = global::ShopdogV1.Properties.Resources.home;
            this.pictureBox3.Location = new System.Drawing.Point(10, 620);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(180, 60);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // butt_notnever_bub
            // 
            this.butt_notnever_bub.BackgroundImage = global::ShopdogV1.Properties.Resources.pur;
            this.butt_notnever_bub.Location = new System.Drawing.Point(0, 300);
            this.butt_notnever_bub.Name = "butt_notnever_bub";
            this.butt_notnever_bub.Size = new System.Drawing.Size(180, 60);
            this.butt_notnever_bub.TabIndex = 5;
            this.butt_notnever_bub.UseVisualStyleBackColor = true;
            this.butt_notnever_bub.Click += new System.EventHandler(this.butt_notnever_bub_Click);
            // 
            // butt_histrory
            // 
            this.butt_histrory.BackgroundImage = global::ShopdogV1.Properties.Resources.salehis;
            this.butt_histrory.Location = new System.Drawing.Point(0, 240);
            this.butt_histrory.Name = "butt_histrory";
            this.butt_histrory.Size = new System.Drawing.Size(180, 60);
            this.butt_histrory.TabIndex = 4;
            this.butt_histrory.UseVisualStyleBackColor = true;
            this.butt_histrory.Click += new System.EventHandler(this.butt_histrory_Click);
            // 
            // butt_selling
            // 
            this.butt_selling.BackgroundImage = global::ShopdogV1.Properties.Resources.sale;
            this.butt_selling.Location = new System.Drawing.Point(0, 180);
            this.butt_selling.Name = "butt_selling";
            this.butt_selling.Size = new System.Drawing.Size(180, 60);
            this.butt_selling.TabIndex = 3;
            this.butt_selling.UseVisualStyleBackColor = true;
            this.butt_selling.Click += new System.EventHandler(this.butt_selling_Click);
            // 
            // butt_push
            // 
            this.butt_push.BackgroundImage = global::ShopdogV1.Properties.Resources.selling;
            this.butt_push.Location = new System.Drawing.Point(0, 120);
            this.butt_push.Name = "butt_push";
            this.butt_push.Size = new System.Drawing.Size(180, 60);
            this.butt_push.TabIndex = 2;
            this.butt_push.UseVisualStyleBackColor = true;
            this.butt_push.Click += new System.EventHandler(this.butt_push_Click);
            // 
            // butt_pro
            // 
            this.butt_pro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butt_pro.Image = global::ShopdogV1.Properties.Resources.pro;
            this.butt_pro.Location = new System.Drawing.Point(0, 60);
            this.butt_pro.Name = "butt_pro";
            this.butt_pro.Size = new System.Drawing.Size(180, 60);
            this.butt_pro.TabIndex = 1;
            this.butt_pro.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.butt_pro.UseVisualStyleBackColor = true;
            this.butt_pro.Click += new System.EventHandler(this.butt_pro_Click);
            // 
            // butt_home
            // 
            this.butt_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.butt_home.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butt_home.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butt_home.Image = global::ShopdogV1.Properties.Resources.home;
            this.butt_home.Location = new System.Drawing.Point(0, 0);
            this.butt_home.Name = "butt_home";
            this.butt_home.Size = new System.Drawing.Size(180, 60);
            this.butt_home.TabIndex = 0;
            this.butt_home.UseVisualStyleBackColor = true;
            this.butt_home.Click += new System.EventHandler(this.butt_home_Click);
            // 
            // imageUser_pic
            // 
            this.imageUser_pic.BackgroundImage = global::ShopdogV1.Properties.Resources.grob;
            this.imageUser_pic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imageUser_pic.Image = global::ShopdogV1.Properties.Resources.user;
            this.imageUser_pic.Location = new System.Drawing.Point(0, 0);
            this.imageUser_pic.Name = "imageUser_pic";
            this.imageUser_pic.Size = new System.Drawing.Size(180, 180);
            this.imageUser_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imageUser_pic.TabIndex = 0;
            this.imageUser_pic.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::ShopdogV1.Properties.Resources.Pub2;
            this.pictureBox2.Location = new System.Drawing.Point(43, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::ShopdogV1.Properties.Resources.shutdown21;
            this.pictureBox1.Location = new System.Drawing.Point(5, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 35);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Main_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.ClientSize = new System.Drawing.Size(1500, 1000);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageUser_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel_main;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox imageUser_pic;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label user_name_label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button butt_selling;
        private System.Windows.Forms.Button butt_push;
        private System.Windows.Forms.Button butt_pro;
        private System.Windows.Forms.Button butt_home;
        private System.Windows.Forms.Button butt_notnever_bub;
        private System.Windows.Forms.Button butt_histrory;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}

