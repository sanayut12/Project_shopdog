﻿namespace ShopdogV1
{
    partial class Register_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Line_box = new System.Windows.Forms.TextBox();
            this.Facebook_box = new System.Windows.Forms.TextBox();
            this.Address_box = new System.Windows.Forms.ComboBox();
            this.error_phone = new System.Windows.Forms.Label();
            this.error_label = new System.Windows.Forms.Label();
            this.Upload_button = new System.Windows.Forms.Button();
            this.Image_profile = new System.Windows.Forms.PictureBox();
            this.Register_button = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Name_box = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Phone_box = new System.Windows.Forms.TextBox();
            this.Email_box = new System.Windows.Forms.TextBox();
            this.Password_box2 = new System.Windows.Forms.TextBox();
            this.Password_box = new System.Windows.Forms.TextBox();
            this.UserName_box = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Image_profile)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(950, 40);
            this.panel1.TabIndex = 2;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::ShopdogV1.Properties.Resources.Pub2;
            this.pictureBox2.Location = new System.Drawing.Point(43, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::ShopdogV1.Properties.Resources.shutdown21;
            this.pictureBox1.Location = new System.Drawing.Point(5, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 35);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.Line_box);
            this.panel2.Controls.Add(this.Facebook_box);
            this.panel2.Controls.Add(this.Address_box);
            this.panel2.Controls.Add(this.error_phone);
            this.panel2.Controls.Add(this.error_label);
            this.panel2.Controls.Add(this.Upload_button);
            this.panel2.Controls.Add(this.Image_profile);
            this.panel2.Controls.Add(this.Register_button);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.Name_box);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.Phone_box);
            this.panel2.Controls.Add(this.Email_box);
            this.panel2.Controls.Add(this.Password_box2);
            this.panel2.Controls.Add(this.Password_box);
            this.panel2.Controls.Add(this.UserName_box);
            this.panel2.Location = new System.Drawing.Point(0, 40);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(950, 610);
            this.panel2.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(177, 386);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 35);
            this.label10.TabIndex = 50;
            this.label10.Text = "Line";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(126, 346);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 35);
            this.label9.TabIndex = 49;
            this.label9.Text = "Facbook";
            // 
            // Line_box
            // 
            this.Line_box.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Line_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Line_box.Location = new System.Drawing.Point(250, 385);
            this.Line_box.MaxLength = 200;
            this.Line_box.Name = "Line_box";
            this.Line_box.Size = new System.Drawing.Size(425, 34);
            this.Line_box.TabIndex = 48;
            // 
            // Facebook_box
            // 
            this.Facebook_box.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Facebook_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Facebook_box.Location = new System.Drawing.Point(250, 345);
            this.Facebook_box.MaxLength = 200;
            this.Facebook_box.Name = "Facebook_box";
            this.Facebook_box.Size = new System.Drawing.Size(425, 34);
            this.Facebook_box.TabIndex = 47;
            // 
            // Address_box
            // 
            this.Address_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address_box.FormattingEnabled = true;
            this.Address_box.Location = new System.Drawing.Point(250, 443);
            this.Address_box.Name = "Address_box";
            this.Address_box.Size = new System.Drawing.Size(425, 37);
            this.Address_box.TabIndex = 46;
            // 
            // error_phone
            // 
            this.error_phone.AutoSize = true;
            this.error_phone.BackColor = System.Drawing.Color.Transparent;
            this.error_phone.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error_phone.Location = new System.Drawing.Point(651, 472);
            this.error_phone.Name = "error_phone";
            this.error_phone.Size = new System.Drawing.Size(0, 26);
            this.error_phone.TabIndex = 45;
            // 
            // error_label
            // 
            this.error_label.AutoSize = true;
            this.error_label.BackColor = System.Drawing.Color.Transparent;
            this.error_label.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error_label.ForeColor = System.Drawing.Color.Red;
            this.error_label.Location = new System.Drawing.Point(244, 208);
            this.error_label.Name = "error_label";
            this.error_label.Size = new System.Drawing.Size(0, 31);
            this.error_label.TabIndex = 44;
            // 
            // Upload_button
            // 
            this.Upload_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.Upload_button.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Upload_button.Location = new System.Drawing.Point(734, 275);
            this.Upload_button.Name = "Upload_button";
            this.Upload_button.Size = new System.Drawing.Size(138, 43);
            this.Upload_button.TabIndex = 43;
            this.Upload_button.Text = "Upload";
            this.Upload_button.UseVisualStyleBackColor = false;
            this.Upload_button.Click += new System.EventHandler(this.Upload_button_Click);
            // 
            // Image_profile
            // 
            this.Image_profile.BackColor = System.Drawing.Color.Transparent;
            this.Image_profile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Image_profile.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Image_profile.Image = global::ShopdogV1.Properties.Resources.user;
            this.Image_profile.Location = new System.Drawing.Point(698, 51);
            this.Image_profile.Name = "Image_profile";
            this.Image_profile.Size = new System.Drawing.Size(209, 205);
            this.Image_profile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Image_profile.TabIndex = 41;
            this.Image_profile.TabStop = false;
            // 
            // Register_button
            // 
            this.Register_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.Register_button.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Register_button.Location = new System.Drawing.Point(392, 515);
            this.Register_button.Name = "Register_button";
            this.Register_button.Size = new System.Drawing.Size(166, 55);
            this.Register_button.TabIndex = 40;
            this.Register_button.Text = "Register";
            this.Register_button.UseVisualStyleBackColor = false;
            this.Register_button.Click += new System.EventHandler(this.Register_button_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(112, 440);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 39);
            this.label7.TabIndex = 39;
            this.label7.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(56, 304);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 35);
            this.label6.TabIndex = 38;
            this.label6.Text = "Phone Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(161, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 35);
            this.label5.TabIndex = 37;
            this.label5.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(5, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(221, 35);
            this.label4.TabIndex = 36;
            this.label4.Text = "Confirm Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(111, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 35);
            this.label3.TabIndex = 35;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(97, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 35);
            this.label2.TabIndex = 34;
            this.label2.Text = "User name";
            // 
            // Name_box
            // 
            this.Name_box.BackColor = System.Drawing.Color.White;
            this.Name_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_box.Location = new System.Drawing.Point(249, 51);
            this.Name_box.MaxLength = 200;
            this.Name_box.Name = "Name_box";
            this.Name_box.Size = new System.Drawing.Size(426, 34);
            this.Name_box.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(155, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 35);
            this.label1.TabIndex = 32;
            this.label1.Text = "Name";
            // 
            // Phone_box
            // 
            this.Phone_box.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Phone_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phone_box.Location = new System.Drawing.Point(249, 305);
            this.Phone_box.MaxLength = 10;
            this.Phone_box.Name = "Phone_box";
            this.Phone_box.Size = new System.Drawing.Size(426, 34);
            this.Phone_box.TabIndex = 31;
            // 
            // Email_box
            // 
            this.Email_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_box.Location = new System.Drawing.Point(249, 265);
            this.Email_box.MaxLength = 200;
            this.Email_box.Name = "Email_box";
            this.Email_box.Size = new System.Drawing.Size(426, 34);
            this.Email_box.TabIndex = 30;
            // 
            // Password_box2
            // 
            this.Password_box2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password_box2.Location = new System.Drawing.Point(249, 171);
            this.Password_box2.MaxLength = 16;
            this.Password_box2.Name = "Password_box2";
            this.Password_box2.Size = new System.Drawing.Size(426, 34);
            this.Password_box2.TabIndex = 29;
            // 
            // Password_box
            // 
            this.Password_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password_box.Location = new System.Drawing.Point(249, 131);
            this.Password_box.MaxLength = 16;
            this.Password_box.Name = "Password_box";
            this.Password_box.Size = new System.Drawing.Size(426, 34);
            this.Password_box.TabIndex = 28;
            // 
            // UserName_box
            // 
            this.UserName_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserName_box.Location = new System.Drawing.Point(249, 91);
            this.UserName_box.MaxLength = 200;
            this.UserName_box.Name = "UserName_box";
            this.UserName_box.Size = new System.Drawing.Size(426, 34);
            this.UserName_box.TabIndex = 27;
            // 
            // Register_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.ClientSize = new System.Drawing.Size(950, 650);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Register_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Image_profile)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Line_box;
        private System.Windows.Forms.TextBox Facebook_box;
        private System.Windows.Forms.ComboBox Address_box;
        private System.Windows.Forms.Label error_phone;
        private System.Windows.Forms.Label error_label;
        private System.Windows.Forms.Button Upload_button;
        private System.Windows.Forms.PictureBox Image_profile;
        private System.Windows.Forms.Button Register_button;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Name_box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Phone_box;
        private System.Windows.Forms.TextBox Email_box;
        private System.Windows.Forms.TextBox Password_box2;
        private System.Windows.Forms.TextBox Password_box;
        private System.Windows.Forms.TextBox UserName_box;
    }
}