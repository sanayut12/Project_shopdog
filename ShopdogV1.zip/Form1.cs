﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopdogV1
{
    public partial class Main_form : Form
    {
        public Main_form(string user)
        {
            InitializeComponent();
            user_name_label.Text = user;
            home_start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void butt_home_Click(object sender, EventArgs e)
        {
            //panel clear
            panel_main.Controls.Clear();

            Home_form hf = new Home_form(user_name_label.Text);
            hf.TopLevel = false;
            panel_main.Controls.Add(hf);
            hf.Show();

        }

        private void butt_pro_Click(object sender, EventArgs e)
        {
            //panel clear
            panel_main.Controls.Clear();

            Profile_form pf = new Profile_form(user_name_label.Text);
            pf.TopLevel = false;
            panel_main.Controls.Add(pf);
            pf.Show();
        }

        private void butt_push_Click(object sender, EventArgs e)
        {
            //panel clear
            panel_main.Controls.Clear();

            Push_form pf = new Push_form(user_name_label.Text);
            pf.TopLevel = false;
            panel_main.Controls.Add(pf);
            pf.Show();
        }

        private void butt_selling_Click(object sender, EventArgs e)
        {
            //panel clear
            panel_main.Controls.Clear();

            selling_form sf = new selling_form(user_name_label.Text);
            sf.TopLevel = false;
            panel_main.Controls.Add(sf);
            sf.Show();
        }

        private void butt_histrory_Click(object sender, EventArgs e)
        {
            //panel clear
            panel_main.Controls.Clear();

            Hestrory_sell_form hsf = new Hestrory_sell_form(user_name_label.Text);
            hsf.TopLevel = false;
            panel_main.Controls.Add(hsf);
            hsf.Show();
        }

        private void butt_notnever_bub_Click(object sender, EventArgs e)
        {
            //panel clear
            panel_main.Controls.Clear();

            Histrory_buy_form hbf = new Histrory_buy_form(user_name_label.Text);
            hbf.TopLevel = false;
            panel_main.Controls.Add(hbf);
            hbf.Show();
        }
        private void home_start()
        {
            //panel clear
            panel_main.Controls.Clear();

            Home_form hf = new Home_form(user_name_label.Text);
            hf.TopLevel = false;
            panel_main.Controls.Add(hf);
            hf.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }
    }
}
